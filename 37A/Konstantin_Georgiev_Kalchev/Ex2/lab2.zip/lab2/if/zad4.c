#include <stdio.h>

int main()
{
    int num;
    printf("Въведи число: ");
    scanf("%d", &num);
    switch (num)
    {
    case 0:
        printf("Nula");
        break;
    case 1:
        printf("Edno");
        break;
    case 2:
        printf("Dve");
        break;
    case 3:
        printf("Tri");
        break;
    case 4:
        printf("Chetiri");
        break;
    case 5:
        printf("Pet");
        break;
    case 6:
        printf("Six");
        break;
    case 7:
        printf("Sedem");
        break;
    case 8:
        printf("Osem");
        break;
    case 9:
        printf("Devet");
        break;
    default:
        printf("въведи цифра!");
        break;
    }

    return 0;
}