#include <stdio.h>

int main()
{
    int num;
    printf("Въведи число: ");
    scanf("%d", &num);
    if (num % 8 >= 4)
    {
        printf("Hi");
    }
    return 0;
}