#include <stdio.h>

int main()
{
    int num;
    printf("Въведи число: ");
    scanf("%d", &num);
    if (num > 6)
    {
        printf("Num > 6");
    }
}