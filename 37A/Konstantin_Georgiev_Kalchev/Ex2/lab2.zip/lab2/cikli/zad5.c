#include <stdio.h>

int main()
{
    int num, sum = 0;
    printf("Въведи числа: ");
    while (num != 0)
    {
        scanf("%d", &num);
        sum += num;
    }
    printf("%d", sum);
    return 0;
}