#include <stdio.h>

int main()
{
    int num1, num2;
    printf("Въведи 2 числа: ");
    scanf("%d %d", &num1, &num2);
    int sum = 0;
    int pr = 1;
    for (int i = num1 + 1; i < num2; i++)
    {
        if (i % 2 == 0)
        {
            sum += i;
        }
        else
        {
            pr = pr * i;
        }
    }
    printf("Pr = %d\n", pr);
    printf("Sum = %d", sum);
    return 0;
}