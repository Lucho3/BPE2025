#include <stdio.h>

int main()
{
    int num1, num2;
    printf("Въведи 2 числа: ");
    scanf("%d %d", &num1, &num2);
    int sum = 0;
    for (int i = num1 + 1; i < num2; i++)
    {
        sum += i;
    }
    printf("%d", sum);
    return 0;
}