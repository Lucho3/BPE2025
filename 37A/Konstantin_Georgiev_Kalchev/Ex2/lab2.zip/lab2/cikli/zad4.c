#include <stdio.h>

int main()
{
    int n, k, br = 0, num;
    printf("Въведи N и К: ");
    scanf("%d %d", &n, &k);
    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &num);
        if (num > k && num % 3 == 0)
        {
            br++;
        }
    }
    printf("%d", br);
}