#include <stdio.h>

int main()
{
    double num1, num2;
    printf("Въведи 2 числа: ");
    scanf("%lf %lf", &num1, &num2);
    for (double i = num1; i <= num2; i = i + 0.1)
    {
        double f = i * i - 4;
        printf("%f\n", f);
    }
    return 0;
}