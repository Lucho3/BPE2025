#include <stdio.h>

int main()
{
    int num;
    printf("Въведи число:");
    scanf("%d", &num);
    for (int i = 1; i <= num; i++)
    {
        printf("\n");
        for (int j = 1; j <= i; j++)
        {
            printf("%d", j);
        }
    }
    return 0;
}